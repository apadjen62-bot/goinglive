# The Daily Badger News Hub

Files:
- `index.html` — homepage/news hub
- `article.html` — featured news article
- `documents/news-article.pdf` — downloadable PDF version

For GitHub Pages, upload the entire folder contents to your repository. The homepage will be `index.html`.
